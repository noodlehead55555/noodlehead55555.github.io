var getAverages = function () {
  //Getting Array
  var newNumber;
  var stringArray = [];
  while (true) {
    newNumber = prompt(
      'What number is wanted next? Press cancel if done inputting numbers.\nYou have submitted ' +
        stringArray.length +
        ' numbers so far.'
    );
    if (newNumber === null) {
      break;
    } else {
      stringArray.push(newNumber);
    }
  }
  //Setting Up
  var Length = stringArray.length;
  var numberArray = [];
  for (k = 0; k < Length; k++) {
    numberArray.push(Number(stringArray[k]));
  }
  //Finding the mean
  var answerArraySum = 0;
  for (i = 0; i < Length; i++) {
    answerArraySum += numberArray[i];
  }
  var mean = answerArraySum / Length;
  //Sorting array
  var p = 0;
  var o;
  var counter = 0;
  while (true) {
    for (k = 0; k < numberArray.length; k++) {
      if (numberArray[p] > numberArray[p + 1]) {
        o = numberArray[p + 1];
        numberArray[p + 1] = numberArray[p];
        numberArray[p] = o;
        counter++;
      }
      p++;
    }
    if (counter === 0) {
      break;
    }
    if (p === numberArray.length) {
      p = 0;
      counter = 0;
    }
  }
  //Finding the mode
  var findMode = a => {
    a = a.slice().sort((x, y) => x - y);

    var bestStreak = 1;
    var bestElem = a[0];
    var currentStreak = 1;
    var currentElem = a[0];

    for (let i = 1; i < a.length; i++) {
      if (a[i - 1] !== a[i]) {
        if (currentStreak > bestStreak) {
          bestStreak = currentStreak;
          bestElem = currentElem;
        }

        currentStreak = 0;
        currentElem = a[i];
      }

      currentStreak++;
    }

    return currentStreak > bestStreak ? currentElem : bestElem;
  };
  var mode = findMode(numberArray);
  //Finding the median of a sorted array
  var median;
  var medianArray = [];
  for (i = 0; i < Length; i++) {
    medianArray[i] = numberArray[i];
  }
  while (medianArray.length > 2) {
    medianArray.pop();
    medianArray.shift();
  }
  if (medianArray.length === 2) {
    median = (medianArray[1] + medianArray[0]) / 2;
  } else {
    median = medianArray[0];
  }
  //Outputting numbers
  alert('The mean is ' + mean);
  alert('The median is ' + median);
  alert('The mode is ' + mode);
  alert(numberArray);
};

var calculate = function () {
  alert(
    eval(
      prompt(
        'Type your expression here! (NO VARIABLES)\nYou can use Math.pow(2, 3) to do 2^3.'
      )
    )
  );
};

var unfinished = function () {
  alert('This is unfinished, please check back later.');
};
document.getElementById ("average").addEventListener ("click", getAverages, false);
document.getElementById ("calculate").addEventListener ("click", calculate, false);
document.getElementById ("tip").addEventListener ("click", unfinished, false);