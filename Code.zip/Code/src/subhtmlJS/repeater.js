var newString = '';
var longText = function (word, howManyTimes, beginningText, endText) {
  newString = '';
  for (i = 0; i < howManyTimes; i++) {
    newString = newString + word;
  }
  return beginningText + newString + endText;
};
var submit = function () {
  document.getElementById('finishedBox').value = longText(
    document.getElementById('wordBox').value,
    document.getElementById('howManyTimesBox').value,
    document.getElementById('beginningTextBox').value,
    document.getElementById('endTextBox').value
  );
};
document.getElementById('wordBox').addEventListener(
  'input',
  function () {
    submit();
  },
  false
);
document.getElementById('howManyTimesBox').addEventListener(
  'input',
  function () {
    submit();
  },
  false
);
document.getElementById('beginningTextBox').addEventListener(
  'input',
  function () {
    submit();
  },
  false
);
document.getElementById('endTextBox').addEventListener(
  'input',
  function () {
    submit();
  },
  false
);
document.getElementById('finishedBox').addEventListener(
  'input',
  function () {
    submit();
  },
  false
);