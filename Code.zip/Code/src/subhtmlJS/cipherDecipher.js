var normalText = document.getElementById('normalText');
var cipheredText = document.getElementById('cipheredText');
//These two functions do the actual ciphering.
var getKeyByValue = function (object, value) {
  return Object.keys(object).find(key => object[key] === value);
};
var cipherDecipher = function (startingText, cipherOrDecipher) {
  //true is cipher.
  //This is the cipher key.
  var cipherKey = {
    A: '(',
    B: 'S',
    C: 'R',
    D: ',',
    E: 'j',
    F: 'E',
    G: 'C',
    H: '?',
    I: 'm',
    J: 'k',
    K: ':',
    L: "'",
    M: 'p',
    N: 'K',
    O: 'x',
    P: 'c',
    Q: '%',
    R: 'W',
    S: '$',
    T: 'h',
    U: '\\',
    V: '1',
    W: 'L',
    X: 'T',
    Y: 'z',
    Z: 'i',
    0: 'J',
    1: '#',
    2: 'N',
    3: 'g',
    4: '`',
    5: 'd',
    6: 't',
    7: '3',
    8: '5',
    9: 'o',
    '!': '@',
    ',': 'a',
    '?': '*',
    "'": 'D',
    '"': '=',
    '/': 'e',
    ' ': '!',
    '.': 'b',
    a: '⚡',
    b: 'X',
    c: 'f',
    d: '☠',
    e: ';',
    f: 'P',
    g: 'F',
    h: '☑',
    i: '"',
    j: '8',
    k: '&',
    l: '4',
    m: 'Y',
    n: '/',
    o: '.',
    p: '^',
    q: '​',
    r: '☡',
    s: '>',
    t: 'ඞ',
    u: '|',
    v: 'v',
    w: '☃',
    x: 'r',
    y: 'G',
    z: 'I',
    '@': 'Z',
    '#': '1',
    $: 'y',
    '%': 'U',
    '^': 'M',
    '&': '9',
    '*': 'u',
    '(': '☓',
    ')': '~',
    ';': 'q',
    ':': 'B',
    '=': '<',
    '>': 'Q',
    '<': '𐑀',
    '\\': ' ',
    '|': 'O',
    '`': '2',
    '~': ')',
    '𐑀': '=',
    ඞ: '6',
    '☃': 'l',
    '☑': 'H',
    '☓': 'w',
    '☡': 'V',
    '☠': 'A',
    '⚡': 'n',
    '​': '7',
    easterEgg: "You won't even see this unless you look at the code.",
  };
  //This next bit does the ciphering.
  if (cipherOrDecipher) {
    var cipheredText = '';
    for (i = 0; i !== startingText.length; i++) {
      if (cipherKey[startingText[i]] === undefined) {
        cipheredText = cipheredText + startingText[i];
      } else {
        cipheredText = cipheredText + cipherKey[startingText[i]];
      }
    }
    return cipheredText;
  } else {
    var decipheredText = '';
    for (i = 0; i !== startingText.length; i++) {
      if (getKeyByValue(cipherKey, startingText[i]) === undefined) {
        decipheredText = decipheredText + startingText[i];
      } else {
        decipheredText =
          decipheredText + getKeyByValue(cipherKey, startingText[i]);
      }
    }
    return decipheredText;
  }
};

//This is the part that changes what's in the boxes.
normalText.addEventListener(
  'input',
  function () {
    cipheredText.value = cipherDecipher(normalText.value, true);
  },
  false
);
cipheredText.addEventListener(
  'input',
  function () {
    normalText.value = cipherDecipher(cipheredText.value, false);
  },
  false
);